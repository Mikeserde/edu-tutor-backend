<template>
  <div class="app-container">
    <el-button type="primary" @click="goBack">返回备份列表</el-button>
  </div>
</template>

<script>
export default {
  name: "BackupRestore",
  methods: {
    goBack() {
      this.$router.push("/backup/list");
    },
  },
};
</script>