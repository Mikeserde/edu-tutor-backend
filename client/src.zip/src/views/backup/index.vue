<template>
  <div class="app-container">
    <!-- 工具栏 -->
    <div class="filter-container">
      <el-button type="primary" icon="el-icon-plus" @click="handleCreate">
        创建备份
      </el-button>
    </div>

    <!-- 备份数据表格 -->
    <el-table
      v-loading="listLoading"
      :data="backupList"
      element-loading-text="数据加载中"
      border
      fit
      highlight-current-row
      style="width: 100%; margin-top: 20px"
      class="backup-table"
    >
      <el-table-column
        prop="backupId"
        align="center"
        label="备份ID"
        min-width="100"
        sortable
      />
      <el-table-column
        prop="backupTime"
        label="备份时间"
        align="center"
        min-width="180"
      >
        <template slot-scope="scope">
          {{ formatDate(scope.row.backupTime) }}
        </template>
      </el-table-column>
      <el-table-column
        prop="comment"
        label="备份说明"
        align="center"
        min-width="200"
      />
      <el-table-column
        align="center"
        label="操作"
        width="180"
        fixed="right"
      >
        <template slot-scope="scope">
          <el-button
            type="primary"
            size="mini"
            @click="handleRestore(scope.row)"
          >
            恢复
          </el-button>
        </template>
      </el-table-column>
    </el-table>

    <!-- 分页组件 -->
    <el-pagination
      background
      :current-page="listQuery.page"
      :page-sizes="[10, 20, 50, 100]"
      :page-size="listQuery.limit"
      layout="total, sizes, prev, pager, next, jumper"
      :total="total"
      @size-change="handleSizeChange"
      @current-change="handleCurrentChange"
      style="margin-top: 20px; text-align: left"
    />
  </div>
</template>

<script>
import { listBackups, createBackup } from "@/api/backup";
import { formatDate } from "@/utils";

export default {
  name: "BackupList",
  data() {
    return {
      backupList: [],
      total: 0,
      listLoading: true,
      listQuery: {
        page: 1,
        limit: 10,
      },
    };
  },
  methods: {
    formatDate,
    handleCreate() {
      this.$prompt("请输入备份说明", "创建备份", {
        confirmButtonText: "确定",
        cancelButtonText: "取消",
      })
        .then(({ value }) => {
          createBackup(value)
            .then((response) => {
              if (response.code === 20000) {
                this.$message.success("备份成功");
                this.fetchData();
              } else {
                this.$message.error(response.message || "备份失败");
              }
            })
            .catch((error) => {
              console.error("备份失败:", error);
              this.$message.error("备份失败");
            });
        })
        .catch(() => {
          this.$message.info("取消创建备份");
        });
    },
    handleRestore(row) {
      this.$confirm(`确定恢复备份 ${row.backupId} 吗？`, "恢复确认", {
        confirmButtonText: "确定",
        cancelButtonText: "取消",
        type: "warning",
      })
        .then(() => {
          restoreBackup(row.backupId)
            .then((response) => {
              if (response.code === 20000) {
                this.$message.success("恢复成功");
                this.fetchData();
              } else {
                this.$message.error(response.message || "恢复失败");
              }
            })
            .catch((error) => {
              console.error("恢复失败:", error);
              this.$message.error("恢复失败");
            });
        })
        .catch(() => {
          this.$message.info("取消恢复备份");
        });
    },
    fetchData() {
      this.listLoading = true;
      listBackups(this.listQuery)
        .then((response) => {
          if (response.code === 20000) {
            this.backupList = response.data.page.records;
            this.total = response.data.page.total;
          } else {
            this.$message.error(response.message || "获取备份列表失败");
          }
          this.listLoading = false;
        })
        .catch((error) => {
          console.error("获取备份列表失败:", error);
          this.$message.error("获取备份列表失败");
        });
    },
    handleSizeChange(val) {
      this.listQuery.limit = val;
      this.fetchData();
    },
    handleCurrentChange(val) {
      this.listQuery.page = val;
      this.fetchData();
    },
  },
  created() {
    this.fetchData();
  },
};
</script>

<style scoped>
.filter-container {
  display: flex;
  align-items: center;
  padding: 15px;
  background: #fff;
  border-radius: 4px;
  box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
  margin-bottom: 20px;
}

.backup-table {
  box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
}
</style>