import request from "@/utils/request";

export function listBackups(params) {
    return request({
        url: "/backup-records",
        method: "get",
        params,
    });
}

export function createBackup(comment) {
    return request({
        url: "/backup-records",
        method: "post",
        data: { comment },
    });
}

export function restoreBackup(backupId) {
    return request({
        url: `/backup-records/${backupId}/restore`,
        method: "put",
    });
}